/* Patrick DeVoney Rossella Diorio Euripides Montagne COP 3402 Fall 2023 HomeWork 3: Tiny PL/0 compiler */

Compile and run the parsercodegen.c in Eustis:

1. In a the same directory on computer place the parsercodegen.c and all input files.
2. Open a command prompt to that directory
3. To compile type: gcc parsercodegen.c
4. Hit enter
5. To run in Eustis type: ./a.out errorin1.txt
6. Hit Enter
7. The output of the parsercodegen.c will be shown in the terminal for that input
8. Repeat steps 5-6 with all different input files
